package company.blind.dao;

import company.blind.dto.MemberDTOTest;

public interface MemberDAOTest {
	
	// 회원 정보 추가 테스트
	public void insertTest(MemberDTOTest mdto);

}
