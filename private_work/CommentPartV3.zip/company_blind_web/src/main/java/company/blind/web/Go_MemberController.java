package company.blind.web;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import company.blind.dto.Go_MemberDTO;
import company.blind.service.Go_MemberService;

@Controller
@RequestMapping("/member/*")
public class Go_MemberController {
	private static final Logger LOGGER = LoggerFactory.getLogger(Go_MemberController.class);
	
	@Inject
	private Go_MemberService gms;
	
	//입력
	@RequestMapping(value = "/write", method = RequestMethod.GET)
	public void writeGET(Go_MemberDTO mdto, Model model) throws Exception{
		LOGGER.info("..... write GET ....");
	}
	
	//쓰기 처리
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String writePost(Go_MemberDTO mdto, RedirectAttributes reAttr) throws Exception {
		LOGGER.info("---- write POST ----");
		LOGGER.info(mdto.toString());
		
		gms.injectMem(mdto);	
		
		return "redirect:/member/list";				
	}
	
	//삭제
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String delete(@RequestParam("mem_num") int mem_num, RedirectAttributes reAttr) throws Exception {
		
		gms.removeMem(mem_num);
		
		return "redirect:/member/list";
	}
	
	//수정 페이지 뷰
	@RequestMapping(value = "/modify", method = RequestMethod.GET)
	public void modifyGET(@RequestParam("mem_num") int mem_num, Model model) throws Exception{		//get으로 보내면 이름이 같으니까 알아서 들어온다?
		model.addAttribute(gms.receiveMem(mem_num));
	}
	
	//수정 처리
	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public String modifyPOST(Go_MemberDTO mdto, RedirectAttributes reAttr) throws Exception{	//알아서 매퍼에서 DTO로 받아오게 되있음
		LOGGER.info("---- 수정 처리 -----");
		
		gms.adjustMem(mdto);
		
		return "redirect:/member/list";
	}		
	
	
	
}
