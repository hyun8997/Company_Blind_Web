package company.blind.web;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import company.blind.dto.CommentDTO;
import company.blind.service.CommentService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
public class CommentServiceTest {
	
	@Inject 
	private CommentService csv;
	
	private static Logger LOGGER = LoggerFactory.getLogger(CommentServiceTest.class);
	
	//@Test
	public void writeTest() throws Exception{
		CommentDTO cdto = new CommentDTO();
		cdto.setMem_id("gil");
		cdto.setCom_cont("11번 댓글");
		cdto.setCom_group(9);			//얘가 10번 댓글이였음 수정, 삭제 테스트 완
		cdto.setBrd_num(2);
		csv.write(cdto);
	}
	
	//@Test
	public void modifyTest() throws Exception{
		CommentDTO cdto = new CommentDTO();
		cdto.setMem_id("gil");
		cdto.setCom_cont("12번 댓글");
		cdto.setCom_group(9);
		cdto.setBrd_num(2);
		cdto.setCmt_num(10);
		csv.modify(cdto);
	}
	
	//@Test
	public void deleteTest() throws Exception{
		csv.delete(10);
	}
	
	//@Test
	public void readTest() throws Exception{
		LOGGER.info(csv.get(5).toString());		//toStrong overide 없어서 db 내용만 나오긴 함
	}
	
	//@Test														//제대로된 상위 댓글을 못 쫓아가는 문제 발생, 해결
	public void listTest() throws Exception{
		List<CommentDTO> clist = csv.list(2);
		
		CommentDTO flash = new CommentDTO();	//잠시 저장, 플레시
		
		int depth_cnt = 0;
		
		for(int i=0;i<clist.size();i++) {		// 비교 기준 댓글
			depth_cnt = 0;
			for(int j=i+1;j<clist.size();j++) {	// 비교중 댓글
				if(clist.get(i).getCmt_num() == clist.get(j).getCom_group()) {
					
					LOGGER.info("상위:"+clist.get(i).getCmt_num());
					LOGGER.info("하위:"+clist.get(j).getCmt_num());
					
					//플레시에 저장해두고
					flash.setBrd_num(clist.get(j).getBrd_num());
					flash.setCmt_num(clist.get(j).getCmt_num());
					flash.setCom_cont(clist.get(j).getCom_cont());
					flash.setCom_group(clist.get(j).getCom_group());
					flash.setCom_lev(clist.get(j).getCom_lev());
					flash.setCom_regdate(clist.get(j).getCom_regdate());
					flash.setMem_id(clist.get(j).getMem_id());
					LOGGER.info("----------------저장완료--------------");
					
					//한칸씩 미루기
					for(int k=j-1; k>i+depth_cnt; k--) {
						LOGGER.info(k+" "+" "+(i+depth_cnt)+" "+depth_cnt);
						LOGGER.info("---------------미루기 시작---------------");
						clist.get(k+1).setBrd_num(clist.get(k).getBrd_num());
						clist.get(k+1).setCmt_num(clist.get(k).getCmt_num());
						clist.get(k+1).setCom_cont(clist.get(k).getCom_cont());
						clist.get(k+1).setCom_group(clist.get(k).getCom_group());
						clist.get(k+1).setCom_lev(clist.get(k).getCom_lev());
						clist.get(k+1).setCom_regdate(clist.get(k).getCom_regdate());
						clist.get(k+1).setMem_id(clist.get(k).getMem_id());
					}
					
					depth_cnt ++;	//깊이를 늘림
					
					LOGGER.info("---------------자리에 넣기---------------");
					clist.get(i+depth_cnt).setBrd_num(flash.getBrd_num());
					clist.get(i+depth_cnt).setCmt_num(flash.getCmt_num());
					clist.get(i+depth_cnt).setCom_cont(flash.getCom_cont());
					clist.get(i+depth_cnt).setCom_group(flash.getCom_group());
					clist.get(i+depth_cnt).setCom_lev(flash.getCom_lev());
					clist.get(i+depth_cnt).setCom_regdate(flash.getCom_regdate());
					clist.get(i+depth_cnt).setMem_id(flash.getMem_id());
					
					
					//중간점검
//					for(int m=0;m<clist.size();m++) {	
//					LOGGER.info(clist.get(m).getCom_cont()+" "+clist.get(m).getCmt_num()+" "+clist.get(m).getCom_group()
//							+" "+clist.get(m).getCom_lev());
//						
//					}
					
				}
				
			}
		}//최종  for end
		
		LOGGER.info("size:"+clist.size());
		
		//LOGGER.info(clist.toString());	
		
		//최종점검
		for(int i=0;i<clist.size();i++) {	
			LOGGER.info(clist.get(i).getCom_cont()+"\t\t"+clist.get(i).getCmt_num()+"\t"+clist.get(i).getCom_group()
					+"\t"+clist.get(i).getCom_lev());
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
