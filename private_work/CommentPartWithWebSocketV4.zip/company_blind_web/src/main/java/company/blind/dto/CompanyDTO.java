package company.blind.dto;

public class CompanyDTO {
	private String com_name;
	
	public CompanyDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getCom_name() {
		return com_name;
	}

	public void setCom_name(String com_name) {
		this.com_name = com_name;
	}
	
	
}
