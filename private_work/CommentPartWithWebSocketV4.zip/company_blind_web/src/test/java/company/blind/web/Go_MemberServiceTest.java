package company.blind.web;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import company.blind.dao.Go_MemberDAO;
import company.blind.dto.Go_MemberDTO;
import company.blind.service.Go_MemberService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
public class Go_MemberServiceTest {
	
	@Inject
	private Go_MemberService gms;
	//private Go_MemberDAO mdao;
	
	private static Logger LOGGER = LoggerFactory.getLogger(Go_MemberServiceTest.class);
	
	//@Test
	public void injectMemTest() throws Exception{
		Go_MemberDTO mdto = new Go_MemberDTO();
		mdto.setMem_id("yu123141");
		mdto.setMem_pwd("123242342345");
		mdto.setMem_email("gghfd512@naver.com");
		mdto.setMem_level(1);
		mdto.setMem_name("유고");
		mdto.setCom_name("구트아카데미");
		
		mdto.setMem_age_range(null);
		mdto.setMem_birth(null);
		mdto.setMem_gender(null);
		mdto.setMem_phone(null);
		
		gms.injectMem(mdto);
		//mdao.insertMem(mdto);
	}
	
	//수정은 비밀번호, 이메일, 전화번호만 가능
	//@Test
	public void adjustMemTest() throws Exception{
		Go_MemberDTO mdto = new Go_MemberDTO();
		mdto.setMem_num(5);
		
		mdto.setMem_id("yu123");
		mdto.setMem_pwd("2345");
		mdto.setMem_email("gwan1234@sun.com");
		mdto.setMem_level(1);
		mdto.setMem_name("유");
		mdto.setCom_name("구트아카데미");
		
		mdto.setMem_age_range(null);
		mdto.setMem_birth(null);
		mdto.setMem_gender(null);
		mdto.setMem_phone(null);
		
		gms.adjustMem(mdto);
	}
	
	//id로 삭제
	//@Test
	public void removeMemTest() throws Exception{
		gms.removeMem(5);
	}
	
	//@Test
	public void receiveMemTest() throws Exception{
		Go_MemberDTO mdto = gms.receiveMem(3);
		
		LOGGER.info(mdto.getMem_id()+" "+mdto.getMem_pwd()+" "+mdto.getMem_email());
	}
	
	//@Test
	public void listTest() throws Exception{
		List<Go_MemberDTO> mlist = gms.allMem();
		
		for(Go_MemberDTO mdto : mlist) {
			LOGGER.info(mdto.getMem_id()+" "+mdto.getMem_pwd()+" "+mdto.getMem_email());
		}
	}
	
	//@Test
	public void listByComTest() throws Exception{
		List<Go_MemberDTO> mlist = gms.allMemByCom("구트아카데미");
		//List<Go_MemberDTO> mlist = gms.allMemByCom("없는것");
		
		for(Go_MemberDTO mdto : mlist) {
			LOGGER.info(mdto.getMem_id()+" "+mdto.getMem_pwd()+" "+mdto.getMem_email());
		}
	}
	
	
	
	
	
	
	
	
}
