package company.blind.web;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import company.blind.dto.CommentDTO;
import company.blind.service.CommentService;


@Controller
@RequestMapping("/comment/*")
public class CommentController {
	private static final Logger LOGGER = LoggerFactory.getLogger(CommentController.class);
	
	@Inject
	private CommentService csv; 
	
	//쓰기 뷰
	@RequestMapping(value = "/write", method = RequestMethod.GET)
	public void writeGET(CommentDTO cdto, Model model) throws Exception{
		LOGGER.info("..... write GET ....");
		
		//model.addAttribute(cdto);
	}
	
	//쓰기 처리
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String writePost(CommentDTO cdto, RedirectAttributes reAttr) throws Exception {
		LOGGER.info("---- write POST ----");
		LOGGER.info(cdto.toString());
		
		csv.write(cdto);	
		
		//reAttr.addFlashAttribute("result", "success");
		
		return "redirect:/comment/list";				
	}
	
	//삭제
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String delete(@RequestParam("cmt_num") int cmt_num, RedirectAttributes reAttr) throws Exception {
		
		csv.delete(cmt_num);
		
		//reAttr.addFlashAttribute("result", "success");
		
		return "redirect:/comment/list";
	}
	
	//수정 페이지 뷰
	@RequestMapping(value = "/modify", method = RequestMethod.GET)
	public void modifyGET(@RequestParam("cmt_num") int cmt_num, Model model) throws Exception{		//get으로 보내면 이름이 같으니까 알아서 들어온다?
		model.addAttribute(csv.get(cmt_num));
	}
	
	//수정 처리
	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public String modifyPOST(CommentDTO cdto, RedirectAttributes reAttr) throws Exception{	//알아서 매퍼에서 DTO로 받아오게 되있음
		LOGGER.info("---- 수정 처리 -----");
		
		csv.modify(cdto);
		
		//reAttr.addFlashAttribute("result", "success");
		
		return "redirect:/comment/list";
	}	
	
	//@RequestParam("brd_num") int brd_num,  뺴둠!!!!!
	
	// select 를 통한 레벨 계산, 띄어쓰기 넣기, 정렬까지 해둠
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public void list(Model model) throws Exception {
		LOGGER.info(".... list 출력 ....");
		
		//빼둔거 2로 설정해둠!!!
		int brd_num=2;
		
		
		List<CommentDTO> clist = csv.list(brd_num);
		
		CommentDTO flash = new CommentDTO();	//잠시 저장, 플레시
		
		int depth_cnt = 0;	//깊이
		
		for(int i=0;i<clist.size();i++) {		// 비교 기준 댓글
			depth_cnt = 0;
			for(int j=i+1;j<clist.size();j++) {	// 비교중 댓글
				if(clist.get(i).getCmt_num() == clist.get(j).getCom_group()) {
					//플레시에 저장해두고
					flash.setBrd_num(clist.get(j).getBrd_num());
					flash.setCmt_num(clist.get(j).getCmt_num());
					flash.setCom_cont(clist.get(j).getCom_cont());
					flash.setCom_group(clist.get(j).getCom_group());
					flash.setCom_lev(clist.get(j).getCom_lev());
					flash.setCom_regdate(clist.get(j).getCom_regdate());
					flash.setMem_id(clist.get(j).getMem_id());
					
					//한칸씩 미루기
					for(int k=j-1; k>i+depth_cnt; k--) {
						clist.get(k+1).setBrd_num(clist.get(k).getBrd_num());
						clist.get(k+1).setCmt_num(clist.get(k).getCmt_num());
						clist.get(k+1).setCom_cont(clist.get(k).getCom_cont());
						clist.get(k+1).setCom_group(clist.get(k).getCom_group());
						clist.get(k+1).setCom_lev(clist.get(k).getCom_lev());
						clist.get(k+1).setCom_regdate(clist.get(k).getCom_regdate());
						clist.get(k+1).setMem_id(clist.get(k).getMem_id());
					}
					
					depth_cnt ++;	//깊이를 늘림
					
					LOGGER.info("---------------자리에 넣기---------------");
					clist.get(i+depth_cnt).setBrd_num(flash.getBrd_num());
					clist.get(i+depth_cnt).setCmt_num(flash.getCmt_num());
					clist.get(i+depth_cnt).setCom_cont(flash.getCom_cont());
					clist.get(i+depth_cnt).setCom_group(flash.getCom_group());
					clist.get(i+depth_cnt).setCom_lev(flash.getCom_lev());
					clist.get(i+depth_cnt).setCom_regdate(flash.getCom_regdate());
					clist.get(i+depth_cnt).setMem_id(flash.getMem_id());
				}//비교 if end
			}//내부 for end
		}//최종  for end		
		
		model.addAttribute("list", clist);
	}
	
	//post로 오면 회원이 쓴 댓글 확인
	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public void listMem(@RequestParam("mem_id") String mem_id, Model model) throws Exception {
		LOGGER.info(".... list by member 출력 ....");
		
		model.addAttribute("list", csv.listMem(mem_id));
	}
	
	
	
	
	
	
	
	
	
	
	
}
