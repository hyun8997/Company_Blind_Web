package company.blind.web;

import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import company.blind.dto.CommentDTO;

public class WebSocketHandler extends TextWebSocketHandler {
	
	// 클라이언트 최초 웹소켓 요청시 생성
	private Set<WebSocketSession> sessions = Collections.synchronizedSet(new HashSet<WebSocketSession>());
	
	// 댓글 달리면 알림
	public void noticeCommented(CommentDTO cdto) throws Exception{
		Iterator<WebSocketSession> iterator = sessions.iterator();
		
		while(iterator.hasNext()) {
			WebSocketSession session = iterator.next();
			try {
				// 클라이언트에게 전송할 메세지를 TextMessage 객체로 생성
				TextMessage message = new TextMessage(cdto.getMem_id()+" : "+cdto.getCom_cont());	//댓글 쓴 사람과 내용
				// TextMessage를 클라이언트에게 전송
				session.sendMessage(message);
			} catch (IOException e) {
				// 전송 중 에러 방생하면 해당 클라이언트와 통신을 담당하는 WebSocketSession 객체 삭제
				iterator.remove();
			}
			
		}
	}
	
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
	}
	
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		// 연결 요청 접수 -> 해당 클라이언트와 통신을 담당하는 WebSocketSession 객체 전달
		// WebSocketSession 객체를 Set에 담아둠
		sessions.add(session);
	}
	
	@Override
	public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
		// 클라이언트와 데이터 송수신중 에러가 발생시 통신담당 객체를 HashSet에서 제거
		sessions.remove(session);
	}
	
	
	
}
